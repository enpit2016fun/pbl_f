function kodomoslidemake() {
    location.href = "https://docs.google.com/forms/d/e/1FAIpQLSdf3XuoV8WVG32845tLcaaqn8C7-G-tU_-N-hWldWkjv9ikUQ/viewform#responses";
   
}